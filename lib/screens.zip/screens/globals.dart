import 'package:cloud_firestore/cloud_firestore.dart';

late CollectionReference BasicsExperimentCollection;
late CollectionReference NumpyExperimentCollection;
late CollectionReference MatplotlibExperimentCollection;
late CollectionReference PandasExperimentCollection;
late CollectionReference SeabornExperimentCollection;
late CollectionReference TensorflowExperimentCollection;
late CollectionReference SklearnExperimentCollection;
late CollectionReference KerasExperimentCollection;
late CollectionReference PytorchExperimentCollection;
